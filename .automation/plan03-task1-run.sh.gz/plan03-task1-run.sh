#!/usr/bin/env bash
set -Eeuo pipefail

ORIGINAL_SHA="$(git rev-parse HEAD)"
STAGE="initialization"
SUCCESS=0
WORKER_PROJECT="darknetra-plan03-task1-worker"

cleanup_worker() {
  docker compose -p "$WORKER_PROJECT" -f docker-compose.yml down -v --remove-orphans >/dev/null 2>&1 || true
}

record_failure() {
  local exit_code="$1"
  trap - EXIT
  cleanup_worker
  if [[ "$SUCCESS" -eq 0 ]]; then
    git reset --hard "$ORIGINAL_SHA" >/dev/null
    mkdir -p docs/verification
    {
      echo '# Plan 03 Task 1 diagnostic'
      echo
      printf -- '- **Failed stage:** `%s`\n' "$STAGE"
      printf -- '- **Source commit:** `%s`\n' "$ORIGINAL_SHA"
      printf -- '- **Exit code:** `%s`\n' "$exit_code"
      printf -- '- **Observed at (UTC):** `%s`\n' "$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
      echo
      echo 'The implementation patch remains staged under `.automation` for a subsequent, evidence-driven retry. No unverified production code was committed.'
    } > docs/verification/plan03-task1-diagnostic.md
    git config user.name 'github-actions[bot]'
    git config user.email '41898282+github-actions[bot]@users.noreply.github.com'
    git add docs/verification/plan03-task1-diagnostic.md
    git commit -m 'docs: record Plan 03 Task 1 diagnostic [skip ci]' >/dev/null
    git push origin HEAD:testing-codex
  fi
  exit "$exit_code"
}
trap 'record_failure $?' EXIT

STAGE="runtime key generation"
make_key() {
  python - <<'PY'
import base64
import secrets
print(base64.b64encode(secrets.token_bytes(32)).decode('ascii'))
PY
}
export DARKNETRA_JWT_SIGNING_KEY_B64="$(make_key)"
export DARKNETRA_FIELD_KEY_V1_B64="$(make_key)"
export DARKNETRA_FIELD_BLIND_INDEX_KEY_B64="$(make_key)"
printf '::add-mask::%s\n' \
  "$DARKNETRA_JWT_SIGNING_KEY_B64" \
  "$DARKNETRA_FIELD_KEY_V1_B64" \
  "$DARKNETRA_FIELD_BLIND_INDEX_KEY_B64"

STAGE="reviewed patch application"
gzip -dc .automation/plan03-task1.patch.gz > /tmp/plan03-task1.patch
git apply --check /tmp/plan03-task1.patch
git apply /tmp/plan03-task1.patch
git diff --check

STAGE="dependency lock and frozen sync"
uv lock 2>&1 | tee /tmp/plan03-task1-lock.log
uv sync --all-packages --dev --frozen 2>&1 | tee -a /tmp/plan03-task1-lock.log

STAGE="jobs migration round trip"
{
  uv run alembic -c apps/api/alembic.ini upgrade head
  uv run alembic -c apps/api/alembic.ini current
  uv run alembic -c apps/api/alembic.ini downgrade 670002e45670
  uv run alembic -c apps/api/alembic.ini upgrade head
  uv run alembic -c apps/api/alembic.ini current
} 2>&1 | tee /tmp/plan03-task1-migration.log

STAGE="Ruff verification"
uv run ruff check . 2>&1 | tee /tmp/plan03-task1-ruff.log

STAGE="focused job and Celery tests"
uv run pytest -q \
  apps/api/tests/unit/test_celery_boundary.py \
  apps/api/tests/integration/test_jobs.py \
  2>&1 | tee /tmp/plan03-task1-focused.log

STAGE="complete Python regression suite"
uv run pytest -q 2>&1 | tee /tmp/plan03-task1-pytest.log

STAGE="Redis restart durability experiment"
JOB_ID="$(PYTHONPATH=apps/api uv run python - <<'PY'
import asyncio
from uuid import uuid4

from darknetra_api.db.session import async_session_factory
from darknetra_api.models.case import Case
from darknetra_api.models.enums import CaseSensitivity
from darknetra_api.models.job import Job
from darknetra_api.models.user import User

async def main():
    async with async_session_factory() as session:
        username = f'restart-owner-{uuid4().hex[:10]}'
        owner = User(
            username=username,
            username_normalized=username,
            display_name='Redis Restart Test Owner',
            password_hash='unused',
            global_roles=[],
            is_active=True,
            must_change_password=False,
        )
        session.add(owner)
        await session.flush()
        case = Case(
            case_code=f'RST-{uuid4().hex[:10].upper()}',
            title='Broker restart durability proof',
            sensitivity=CaseSensitivity.STANDARD,
            owner_user_id=owner.id,
            source_authority_summary='Authorized synthetic test',
        )
        session.add(case)
        await session.flush()
        job = Job(
            case_id=case.id,
            resource_type='evidence',
            resource_id=str(uuid4()),
            task_name='darknetra.ingestion.process_evidence',
            idempotency_key=f'ingest:{uuid4()}:v1',
        )
        session.add(job)
        await session.commit()
        print(job.id)

asyncio.run(main())
PY
)"
PYTHONPATH=apps/api uv run python - <<'PY'
import asyncio
import os
from redis.asyncio import Redis

async def main():
    client = Redis.from_url(os.environ['DARKNETRA_REDIS_URL'])
    try:
        await client.set('darknetra:task1:transient', 'present')
    finally:
        await client.aclose()

asyncio.run(main())
PY
REDIS_CONTAINER="$(docker ps --filter ancestor=redis:7.4-alpine --format '{{.ID}}' | head -n 1)"
test -n "$REDIS_CONTAINER"
docker restart "$REDIS_CONTAINER" >/dev/null
for _ in $(seq 1 30); do
  if docker exec "$REDIS_CONTAINER" redis-cli ping 2>/dev/null | grep -q PONG; then
    break
  fi
  sleep 1
done
docker exec "$REDIS_CONTAINER" redis-cli ping | grep -q PONG
export JOB_ID
PYTHONPATH=apps/api uv run python - <<'PY'
import asyncio
import os
from uuid import UUID

from darknetra_api.db.session import async_session_factory
from darknetra_api.models.job import Job, JobState
from redis.asyncio import Redis

async def main():
    redis = Redis.from_url(os.environ['DARKNETRA_REDIS_URL'], decode_responses=True)
    try:
        assert await redis.get('darknetra:task1:transient') is None
    finally:
        await redis.aclose()
    async with async_session_factory() as session:
        job = await session.get(Job, UUID(os.environ['JOB_ID']))
        assert job is not None
        assert job.state is JobState.PENDING
        assert job.attempt_count == 0

asyncio.run(main())
PY
printf 'Redis restarted; PostgreSQL job %s remained authoritative.\n' "$JOB_ID" \
  | tee /tmp/plan03-task1-broker-restart.log

STAGE="Compose topology validation"
docker compose -f docker-compose.yml -f docker-compose.dev.yml config >/tmp/plan03-task1-compose.log

STAGE="real Redis and Celery worker smoke"
docker compose -p "$WORKER_PROJECT" -f docker-compose.yml up -d --build postgres redis worker
WORKER_ID="$(docker compose -p "$WORKER_PROJECT" -f docker-compose.yml ps -q worker)"
test -n "$WORKER_ID"
for _ in $(seq 1 45); do
  STATUS="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$WORKER_ID")"
  if [[ "$STATUS" == "healthy" ]]; then
    break
  fi
  if [[ "$STATUS" == "unhealthy" ]]; then
    docker logs "$WORKER_ID"
    exit 1
  fi
  sleep 2
done
test "$(docker inspect --format '{{.State.Health.Status}}' "$WORKER_ID")" = healthy
docker compose -p "$WORKER_PROJECT" -f docker-compose.yml exec -T worker \
  uv run --no-sync celery -A darknetra_api.jobs.celery_app:celery_app \
  inspect ping --timeout=10 | tee /tmp/plan03-task1-worker.log
cleanup_worker

STAGE="verified implementation commit"
git config user.name 'github-actions[bot]'
git config user.email '41898282+github-actions[bot]@users.noreply.github.com'
rm -f docs/verification/plan03-task1-diagnostic.md
git rm -f --ignore-unmatch \
  .automation/plan03-task1.patch.gz \
  .automation/plan03-task1-run.sh.gz \
  .automation/plan03-task1.patch.gz.b64 \
  .automation/plan03-task1-run.sh.gz.b64 \
  .github/workflows/plan03-task1-apply.yml
git add .env.example uv.lock apps/api docker-compose.yml docker-compose.dev.yml scripts/create_e2e_fixture.py
git commit -m 'feat: add durable analysis job boundary'
CODE_SHA="$(git rev-parse HEAD)"
OBSERVED_UTC="$(date -u +'%Y-%m-%dT%H:%M:%SZ')"

STAGE="verification record"
python - "$CODE_SHA" "$OBSERVED_UTC" <<'PY'
from pathlib import Path
import sys

code_sha, observed_utc = sys.argv[1:]
ledger = Path('docs/verification/plan03-execution-ledger.md')
text = ledger.read_text(encoding='utf-8')
text = text.replace(
    '- Mandatory Plan 03a encryption boundary: final rerun in progress; Plan 03 production implementation does not begin until every Plan 03a gate is green.',
    '- Mandatory Plan 03a encryption boundary: complete and green.',
)
text = text.replace(
    '- Task 1: pending Plan 03a final green gate.',
    f'- Task 1: complete — durable PostgreSQL job boundary, Redis/Celery delivery, migration, and worker smoke verified at `{code_sha}`.',
)
ledger.write_text(text, encoding='utf-8')

lines = [
    '# Plan 03 Task 1 — durable analysis job boundary verification',
    '',
    f'- **Verified code commit:** `{code_sha}`',
    f'- **Observed at (UTC):** `{observed_utc}`',
    '- **Runner:** GitHub Actions `ubuntu-latest`',
    '',
    '| Gate | Outcome |',
    '|---|---|',
    '| Runtime-only test keys | success |',
    '| Reviewed patch application | success |',
    '| `uv lock` + frozen workspace sync | success |',
    '| Alembic upgrade/downgrade/upgrade | success |',
    '| `uv run ruff check .` | success |',
    '| Focused job/Celery tests | success |',
    '| Complete Python regression suite | success |',
    '| Redis restart durability experiment | success |',
    '| Development Compose configuration | success |',
    '| Real Redis/Celery worker health and ping | success |',
    '| Isolated worker-stack teardown | success |',
    '',
    '## Verified architecture',
    '',
    '- PostgreSQL `jobs` rows are authoritative for `PENDING`, `RUNNING`, `RETRYING`, `SUCCEEDED`, and `FAILED` states.',
    '- Redis is a transient delivery broker only; restarting it removed transient broker data without deleting the persisted job row.',
    '- Celery accepts JSON only, disables pickle, uses bounded task limits, late acknowledgement, worker-loss rejection, one-message prefetch, and explicit publish retry.',
    '- The base Compose topology exposes no Redis host port. The development override binds Redis only to `127.0.0.1`.',
    '- The worker listens only on the `ingest` queue and passed an actual Celery inspect ping.',
    '',
    '## Next task',
    '',
    'Plan 03 Task 2 may attach jobs to evidence resources while keeping evidence metadata, lineage, custody, and encrypted source fields authoritative in PostgreSQL.',
    '',
]
Path('docs/verification/plan03-task1-jobs.md').write_text('\n'.join(lines), encoding='utf-8')
PY

git add docs/verification/plan03-execution-ledger.md docs/verification/plan03-task1-jobs.md
git commit -m 'docs: verify Plan 03 Task 1 job boundary [skip ci]'
git push origin HEAD:testing-codex
SUCCESS=1
trap - EXIT
cleanup_worker
